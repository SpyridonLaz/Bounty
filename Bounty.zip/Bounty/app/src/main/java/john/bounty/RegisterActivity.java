package john.bounty;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class RegisterActivity extends Activity {

    private EditText REGemail, REGpassword, REGrepassword,REGname,REGage;
    private TextView status;
    private RelativeLayout sublayout1,sublayout2;
    private Button REGregister;
    static String email , password, name,age;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        sublayout1 =(RelativeLayout) findViewById(R.id.sublayout1);
        sublayout2 =(RelativeLayout) findViewById(R.id.sublayout2);
        sublayout2.setVisibility(View.GONE);

        REGemail = (EditText) findViewById(R.id.REGemail);
        REGpassword = (EditText) findViewById(R.id.REGpassword);
        REGrepassword = (EditText) findViewById(R.id.REGrepassword);
        REGname  = (EditText) findViewById(R.id.REGname);
        REGage  = (EditText) findViewById(R.id.REGage);
        REGregister = (Button) findViewById(R.id.REGregister);



        status = (TextView)findViewById(R.id.status);
    }

    public void hideKeyboardRegister(View view)
    {
            InputMethodManager immRegister = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        immRegister.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    public void layer2(View view){
        sublayout2.setVisibility(View.GONE);
        sublayout1.setVisibility(View.VISIBLE);
    }

    public void layer1(View view){
        sublayout1.setVisibility(View.GONE);
        sublayout2.setVisibility(View.VISIBLE);
    }


void   uploadAvatar(){


    //// TODO: 12/10/2015  UPLOAD AVATAR FILE  +SHARED PREFERENCES.KTLP.

    }


    public void RegisterPost(View view) {


        REGregister.setEnabled(false);

        Timer buttonTimer = new Timer();
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        REGregister.setEnabled(true);
                    }
                });
            }
        }, 2000);


        email = REGemail.getText().toString();
        password = REGpassword.getText().toString();
        name = REGname.getText().toString();
        age = REGage.getText().toString();

        String repassword = REGrepassword.getText().toString();

        String link = "http://bountyapp.esy.es/register.php";
        String user = email +"!"+ password +"!"+ name +"!"+ age +"!";


        if ( !email.isEmpty() && !password.isEmpty() && !name.isEmpty()&& !age.isEmpty() && !repassword.isEmpty()) {
            if (password.equals(repassword)) {

                new SigninActivity(this, status).execute(user, link);





            } else {
                status.setText("Passwords do not match!");
            }
        }
        else{
            status.setText("Fill in empty fields!");
        }
    }
}