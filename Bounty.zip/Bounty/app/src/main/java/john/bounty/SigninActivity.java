package john.bounty;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;


public class SigninActivity extends AsyncTask<String, Void ,String>  {


    private TextView statusField;
    private Context context;
    String[] tempArray;

    //ProgressDialog  pDialog;



    public SigninActivity(Context context, TextView statusField) {
        this.context = context;
        this.statusField = statusField;

    }

    protected void onPreExecute() {
       super.onPreExecute();
      //  pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
     // pDialog.show();


    }


    @Override
    protected String doInBackground(String... arg0) {


        try {
            String user = (String) arg0[0];
            String link = (String) arg0[1];



            String data = URLEncoder.encode("u", "UTF-8") + "=" + URLEncoder.encode(user, "UTF-8");
            //  data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");


            URL url = new URL(link);
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line;

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }

            return sb.toString();
        } catch (Exception e) {
            return e.getMessage();
        }

    }


    @Override
    public void onPostExecute(String result) {

       // pDialog.dismiss();

        tempArray = result.split("!");



        this.statusField.setText(tempArray[0]);

        switch (tempArray[0]) {

            case "REGISTERED":
                context.startActivity(new Intent(context, MainActivity.class));
                break;


            case "MODIFIED":
                break;


            case "LOGGED":


                SharedPreferences.Editor editor = MainActivity.sharedprefs.edit();
                editor.putString(String.valueOf(R.string.Name), tempArray[1]);
                editor.putString(String.valueOf(R.string.Age), tempArray[2]);


                if (MainActivity.checkBox.isChecked()) {
                    editor.putString(String.valueOf(R.string.Email), MainActivity.email);
                    editor.putString(String.valueOf(R.string.Password), MainActivity.password);
                }
                editor.apply();
                context.startActivity(new Intent(context, LogoutActivity.class));

                break;
        }

    }

}