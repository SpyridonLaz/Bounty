package john.bounty;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity  extends Activity {

    private EditText liEmail, liPassword;
    private TextView status;
    private Button myButton, myButton2;
    public static SharedPreferences sharedprefs;
    static  String email,password;
    static CheckBox checkBox;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        liEmail = (EditText) findViewById(R.id.liEmail);
        liPassword = (EditText) findViewById(R.id.liPassword);
        status = (TextView) findViewById(R.id.status);
        checkBox = (CheckBox) findViewById(R.id.checkBox);
        myButton = (Button) findViewById(R.id.liLogin);
        myButton2 = (Button) findViewById(R.id.liRegister);
        sharedprefs = getSharedPreferences(String.valueOf(R.string.myPrefs), Context.MODE_PRIVATE);



            if(sharedprefs.contains(String.valueOf(R.string.Email))) {
            liEmail.setText(sharedprefs.getString(String.valueOf(R.string.Email), ""));
            liPassword.setText(sharedprefs.getString(String.valueOf(R.string.Password), ""));

            SharedPreferences.Editor editor = sharedprefs.edit();
            editor.clear();
            editor.apply();

        }


    }




    public void hideKeyboardMain(View view) {
        InputMethodManager immMain = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        immMain.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }


    public void loginPost(View view) {


        myButton.setEnabled(false);

        Timer buttonTimer = new Timer();
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        myButton.setEnabled(true);
                    }
                });
            }
        }, 2000);

        password = liPassword.getText().toString();
        email = liEmail.getText().toString();


        String link = "http://bountyapp.esy.es/login.php";
        String user = email + "!" + password + "!";


        if (!email.isEmpty() && !password.isEmpty()) {
                new SigninActivity(this, status).execute(user, link);
        } else {
            status.setText("Invalid email and/or password.");
        }

    }






    public void RegisterActivity(View view) {

        myButton2.setEnabled(false);

        Timer buttonTimer = new Timer();
        buttonTimer.schedule(new TimerTask() {

            @Override
            public void run() {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        myButton2.setEnabled(true);
                    }
                });
            }
        }, 2000);



        startActivity(new Intent(this, RegisterActivity.class));
    }

}